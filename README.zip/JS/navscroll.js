const toggle = document.querySelector(".nav-toggle");
const navbar = document.querySelector(".navbar");
const links = document.querySelectorAll('.navbar a[href^="#"]');

const closeNavigation = () => {
    navbar.classList.remove("is-open");
    document.body.classList.remove("menu-open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open navigation");
};

const openNavigation = () => {
    navbar.classList.add("is-open");
    document.body.classList.add("menu-open");
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Close navigation");
};

toggle.addEventListener("click", () => {
    if (navbar.classList.contains("is-open")) {
        closeNavigation();
    } else {
        openNavigation();
    }
});

links.forEach((link) => {
    link.addEventListener("click", (event) => {
        const target = document.querySelector(link.getAttribute("href"));
        if (!target) return;
        event.preventDefault();
        closeNavigation();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeNavigation();
});

window.addEventListener("resize", () => {
    if (window.innerWidth > 768) closeNavigation();
});
